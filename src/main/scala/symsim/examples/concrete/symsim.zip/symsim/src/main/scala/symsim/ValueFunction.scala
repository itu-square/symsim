package symsim

import cats.Monad
import cats.syntax.functor.*
import cats.syntax.flatMap.*
import cats.syntax.foldable.*
import cats.syntax.option.*

import org.scalacheck.Gen
import org.typelevel.paiges.Doc

trait ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]:
   type VF = Any
   def bestAction (vf: VF) (s: State): Action
   def chooseAction (vf: VF) (s: State): Scheduler[Action]
   def initialize: VF

// QTable
class StateActionValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]
  extends ValueFunction[State, ObservableState, Action, Reward, Scheduler]:

//   type VF = Map[ObservableState, Map[Action, Reward]]

   def bestAction (q: VF) (s: State): Action = ???

   def chooseAction (q: VF) (s: State): Scheduler[Action] = ???

   def initialize = ???
