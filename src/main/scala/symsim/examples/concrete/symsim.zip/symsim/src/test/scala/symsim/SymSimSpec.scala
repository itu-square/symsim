package symsim

trait SymSimSpec
  extends org.typelevel.discipline.scalatest.FunSuiteDiscipline
  with org.scalatest.funsuite.AnyFunSuiteLike
  with org.scalatest.prop.Configuration
