package symsim
package examples.concrete.breakingSym

import CanTestIn.*
import org.scalatest.*
import prop.*
import org.scalacheck.Arbitrary.*
import org.scalacheck.Gen
import org.scalatest.prop.Whenever
import org.scalatest.prop.Configuration
import org.scalatest.*
import org.scalacheck.Prop.{exists, forAll, forAllNoShrink, propBoolean}
import examples.concrete.breakingSym.CarState
import examples.concrete.breakingSym.Car

import symsim.concrete.ConcreteSarsa
import cats.kernel.laws.*
import cats.kernel.laws.discipline.*
import cats.kernel.BoundedEnumerable
import symsim.concrete.Randomized

/** Sanity tests for Randomized as a Scheduler */
class CarSpec
   extends org.scalatest.freespec.AnyFreeSpec
   with org.scalatestplus.scalacheck.Checkers:

   implicit override val generatorDrivenConfig =
       PropertyCheckConfiguration(minSuccessful = 100)

   "Sanity checks for symsim.concrete.breakingSym" - {

       // Generators of test data
       val positions = Gen.choose[Double] (0.0, 10.0)
       val velocities = Gen.choose[Double] (0.0,10.0)
       val actions = Gen.oneOf (Car.instances.enumAction.membersAscending)
       val sarsa = ConcreteSarsa(Car, 0.1, 0.1, 0.09, 5000)
       val states = Gen.oneOf(sarsa.agent.instances.allFiniteStates)
       val all_states = sarsa.agent.instances.arbitraryState.arbitrary



       // Tests

       "The car cannot move backwards" in check {
          forAll (positions, actions) { (p, a) =>
             val (s1, r) = Car.step (CarState (v = 0.0, p = p, Car.getPC(p, v = 0.0))) (a).head
             (a <= 0) ==> (s1.p >= p)
          }
       }


       "Position never becomes negative" in check {
          forAll (velocities, positions, actions) { (v, p, a) =>
             val (s1, r) = Car.step (CarState (v = v, p = p, Car.getPC(p, v))) (a).head
             s1.p >= 0.0
          }
       }


       "Reward is valid 1" in check {
          forAll  (positions, positions, velocities, actions) { (p1, p2, v, a) =>
             val r1 = Car.step (CarState (v = v, p = p1, Car.getPC(p = p1, v))) (a).head._2
             val r2 = Car.step (CarState (v = v, p = p2, Car.getPC(p = p2, v))) (a).head._2
             p1 <= p2 ==> r1 >= r2
          }
       }


       "Reward is valid 2" in check {
          forAll (velocities, velocities, positions, actions) { (v1, v2, p, a) =>
             val r1 = Car.step (CarState (v1, p, Car.getPC(p, v1))) (a).head._2
             val r2 = Car.step (CarState (v2, p, Car.getPC(p, v2))) (a).head._2
             v1 <= v2 ==> r1 >= r2
          }
       }


//       "checking the Q values change correctly given two different initial states" in check {
//           forAll (states, states) { (s_1, s_2) =>
//               val initials = Randomized.repeat (sarsa.agent.initialize).take (sarsa.episodes)
//               val Q =  sarsa.learn (sarsa.initQ, initials).head
//               (s_1.p <= s_2.p && s_1.v <= s_2.v ) ==>
//                       forAll (actions) { (a_t) => Q (s_1)(a_t)>= Q (s_2)(a_t)}
//
//           }
//       }
//
//
//       "checking only one cell changes per epoch" in check {
//           forAllNoShrink(states,actions,actions){(s_1,a_1,a_2)=>
//               val Q = sarsa.learningEpoch(sarsa.initQ,s_1,a_1).head._1
//               a_2 != a_1 ==> (Q(s_1)(a_2) == sarsa.initQ(s_1)(a_2))
//
//           }
//       }
//
//
//       "checking Q values change correctly if gamma=0 and alpha=1" in check {
//           forAllNoShrink (all_states,actions) { (s_1, a_1) =>
//               val sarsa= ConcreteSarsa(Car, 1.0, 0.0, 0.09, 500)
//               val Q = sarsa.learningEpoch(sarsa.initQ, s_1, a_1).head._1
//               !sarsa.agent.isFinal (s_1)==> (Q (s_1) (a_1) == sarsa.initQ (s_1) (a_1) + Car.step (s_1) (a_1).head._2)
//
//           }
//       }

       "checking Q values become closer to the optimal Q values with running more episodes (with no exploration)" in check {
           forAllNoShrink (states, actions) { (s_1, a_1) =>
               val sarsa_0= ConcreteSarsa(Car, 0.1, 0.1, 0.0, 100)
               val sarsa_1= ConcreteSarsa(Car, 0.1, 0.1, 0.0, 100)
               val sarsa_2= ConcreteSarsa(Car, 0.1, 0.1, 0.0, 100)
               val initials = Randomized.repeat (sarsa_0.agent.initialize).take (sarsa_0.episodes)
               val Q_0 = sarsa_0.learn (sarsa_0.initQ, initials).head
               val Q_1 = sarsa_1.learn (sarsa_1.initQ, initials).head
               val Q_2 = sarsa_2.learn (sarsa_2.initQ, initials).head
               forAllNoShrink(states,actions){(s_t, a_t)=> (Math.abs (Q_0 (s_1)(a_t) - Q_1 (s_1)(a_t)) <= Math.abs(Q_0 (s_1)(a_t) - Q_2 (s_1)(a_t)))}

           }
       }

       "checking effect of no exploration" in check {
           forAllNoShrink (states) { (s_1) =>
               val sarsa_1 = ConcreteSarsa(Car, 0.1, 0.1, 0.5, 500)
               val sarsa_2 = ConcreteSarsa(Car, 0.1, 0.1, 0.5, 500)
               forAll (velocities, positions) { (v, p) =>
                   val Q_1 = sarsa_1.learningEpisode(sarsa_1.initQ, CarState(v, p, Car.getPC(p, v))).head
                   val Q_2 = sarsa_2.learningEpisode(sarsa_2.initQ, CarState(v, p, Car.getPC(p, v))).head
                   forAllNoShrink(actions, actions) { (a_1, a_2) =>
                       a_1 < a_2 ==> Q_1(s_1)(a_1) >= Q_2(s_1)(a_2)
                   }
               }
           }
       }
    }
