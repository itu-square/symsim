package symsim
package examples.concrete.breakingSym

import CanTestIn.*
import org.scalatest.*
import prop.*
import org.scalacheck.Arbitrary.*
import org.scalacheck.Gen
import org.scalatest.prop.Whenever
import org.scalatest.*
import org.scalacheck.Prop.{exists, forAll, forAllNoShrink, propBoolean}
//import examples.concrete.breakingSym.CarState
//import examples.concrete.breakingSym.Car

import symsim.concrete.ConcreteSarsa
import cats.kernel.laws.*
import cats.kernel.laws.discipline.*
import cats.kernel.BoundedEnumerable
import symsim.concrete.Randomized

/** Sanity tests for Randomized as a Scheduler */
class ConVsSym
   extends org.scalatest.freespec.AnyFreeSpec
   with org.scalatestplus.scalacheck.Checkers:

   implicit override val generatorDrivenConfig =
       PropertyCheckConfiguration(minSuccessful = 10)


   "Sanity checks for symsim.concrete.breakingSym" - {

       // Generators of test data
       val positions = Gen.choose[Double] (0.0, 10.0)
       val velocities = Gen.choose[Double] (0.0,10.0)
       val sarsa_1 = ConcreteSarsa(examples.concrete.breakingSym.Car, 0.1, 0.1, 0.5, 10000)
       val sarsa_2 = ConcreteSarsa(examples.concrete.breaking.Car, 0.1, 0.1, 0.5, 10000)
       val states_1 = Gen.oneOf(sarsa_1.agent.instances.allFiniteStates)
       val states_2 = Gen.oneOf(sarsa_2.agent.instances.allFiniteStates)
       val actions = Gen.oneOf (examples.concrete.breakingSym.Car.instances.enumAction.membersAscending)
//       val all_states = sarsa.agent.instances.arbitraryState.arbitrary


       "Step function works same" in check {
           forAll (velocities, positions, actions) { (v, p, a) =>
               val (s1, r1) = Car.step (CarState (v = v, p = p, Car.getPC(p, v))) (a).head
               val (s2, r2) = examples.concrete.breaking.Car.step (examples.concrete.breaking.CarState (v = v, p = p)) (a).head
               s1.p == s2.p && s1.v == s2.v && r1 == r2
           }
       }

       "All Q values are negative or zero" in check {
           forAll (velocities, positions) { (v, p) =>
               val Q_1 = sarsa_1.learningEpisode(sarsa_1.initQ, CarState(v, p, Car.getPC(p, v))).head
               val Q_2 = sarsa_2.learningEpisode(sarsa_2.initQ, examples.concrete.breaking.CarState (v = v, p = p)).head
               forAllNoShrink(actions) { (a) =>
                   Q_1(ObservableCarState(Car.getPC(p, v)))(a) <= 0 && Q_2(examples.concrete.breaking.Car.discretize(examples.concrete.breaking.CarState (v = v, p = p)))(a) <= 0
               }
           }
       }

       "Q_symbolic is better than Q_concrete " in check {
           forAllNoShrink (velocities, positions) { (v, p) =>
               val Q_1 = sarsa_1.learn (sarsa_1.initQ, Randomized.repeat (sarsa_1.agent.initialize).take (sarsa_1.episodes)).head
               val Q_2 = sarsa_2.learn (sarsa_2.initQ, Randomized.repeat (sarsa_2.agent.initialize).take (sarsa_2.episodes)).head

               val symQ = for {
                   a <- Car.instances.allActions
                   q = Q_1(ObservableCarState(Car.getPC(p, v)))(a)
               } yield q

               val conQ = for {
                   a <- Car.instances.allActions
                   q = Q_2(examples.concrete.breaking.Car.discretize(examples.concrete.breaking.CarState (v = v, p = p)))(a)
               } yield q

               val maxSym = symQ.sorted(Ordering[Double].reverse).find(x => x < 0).getOrElse(Double.MinValue)
               val maxCon = conQ.sorted(Ordering[Double].reverse).find(x => x < 0).getOrElse(Double.MinValue)

               print(maxSym)
               print(", ")
               print(maxCon)
               println()

               maxSym >= maxCon
           }
       }
   }
