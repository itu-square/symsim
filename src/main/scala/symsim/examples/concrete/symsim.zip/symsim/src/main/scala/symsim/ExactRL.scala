package symsim

import cats.Monad
import cats.syntax.functor.*
import cats.syntax.flatMap.*
import cats.syntax.foldable.*
import cats.syntax.option.*

import org.scalacheck.Gen
import org.typelevel.paiges.Doc

abstract class ExactRL[State, ObservableState, Action, Reward, Scheduler[_], ValueFunction[_,_,_,_,_]]
  (vf: ValueFunction[State, ObservableState, Action, Reward, Scheduler[Action]])
  extends RL[ObservableState, Action]:

   import agent.instances.given

   val agent: Agent[State, ObservableState, Action, Reward, Scheduler]

   def alpha: Double
   def gamma: Double

   /** A single step of the learning algorithm
     *
     * @param q the last Q-matrix
     * @param s_t current state
     * @return the updated matrix Q, the successor state, and a
     * reward difference (the size of the update performed)
     *
     * To acommodate Q-Learning and SARSA in a single design, we receive
     * the action a_t to the iteration, and we also produce the action a_t
     * for the next iteration.  This allows SARSA to pass over the 'lookahead'
     * to the next iteration and stay properly on policy.  In Q-Learning this
     * introduces a small presentation complication, not more.
     */
   def learningEpoch (f: vf.VF, s_t: State, a_t: Action): Scheduler[(VF, State, Action)]

   /** Execute a full learning episode (until the final state of agent is
     * reached).
     */
   def learningEpisode (f: vf.VF, s_t: State): Scheduler[VF] =
      def p (vf: VF, s: State, a: Action): Boolean =
         agent.isFinal (s)
      for
         a <- vf.chooseAction (s_t)
         fin <- Monad[Scheduler].iterateUntilM (vf, s_t, a) (learningEpoch) (p)
      yield fin._1

   /** Construct a zero initialized Q matrix */
   def initVF: ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]

   /** Executes as many full learning episodes (until the final state of agent is
     * reached) as the given state scheduler generates.  For this method to work
     * the scheduler needs to be foldable, and we use foldRight with Eval, to
     * make the evaluation lazy. We force the evaluation when we
     * are done to return the value.  However, to my best understanding, if the
     * Scheduler is lazy then the evaluation is not really doing more than just
     * formulating the thunk of that scheduler.
     */
   final def learn (vf: ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]], ss: => Scheduler[State]):
   Scheduler[ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]] =
      ss.foldM[Scheduler, ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]] (vf) (learningEpisode)

   /** Convert the matrix Q after training into a Policy map. TODO: should not
     * this be using the bestAction method? Or, why is the best action method
     * abstract? Or is qToPolicy too concrete to be here?
     */
   def vFToPolicy (vf: ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]) (using Ordering[Reward]):
   Policy =
     def best (m: Map[Action,Reward]): Action =
       m.map { _.swap } (m.values.max)
     vf.view.mapValues (best).to (Map)


   /** Generate total Q matrices for testing. */
   val genVF: Gen[ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]] =
      val as = agent.instances.allActions
      val genReward = agent.instances.arbitraryReward.arbitrary
      val genActionReward: Gen[Map[Action,Reward]] = for
        // TODO refactor, seek what is available for maps
        rewards <- Gen.sequence[List[Reward], Reward]
          { List.fill (as.size) (genReward) }
        ars = as zip rewards
      yield Map (ars: _*)

      val fs = agent.instances.allObservableStates
      val genStateActionRewards: Gen[ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]] = for
        // TODO refactor, seek what is available for maps
        mars <- Gen.sequence[List[Map[Action,Reward]], Map[Action,Reward]]
          { List.fill (fs.size) (genActionReward) }
        smars = fs zip mars
      yield Map (smars: _*)

      genStateActionRewards



   /** We assume that all values define the same set of actions valuations.  */
   def pp_VF (vf: ValueFunction[State, ObservableState, Action, Reward, Scheduler[_]]): Doc =
      val headings = "" ::vf
         .values
         .head
         .keys
         .map (_.toString)
         .toList
         .sorted
      def fmt (s: ObservableState, m: Map[Action,Reward]): List[String] =
         s.toString ::m
            .toList
            .sortBy (_._1.toString)
            .map { _._2.toString.take (7).padTo (7,'0') }
      val rows = vf
         .toList
         .sortBy (_._1.toString)
         .map (fmt)
      symsim.tabulate (' ', " | ", headings ::rows, "-".some, "-+-".some)
